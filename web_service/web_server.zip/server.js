// server.mjs
import Fastify from 'fastify';
import 'dotenv/config'
import salesPlugin from './plugins/sales.mjs';
import cors from '@fastify/cors';

const DB_USER = process.env.DB_USER;
const DB_PASSWORD = process.env.DB_PASSWORD;
const DB_NAME = process.env.DB_NAME;
const DB_HOST = process.env.DB_HOST;

const fastify = Fastify({ logger: true });

// Daftarkan plugin CORS
fastify.register(cors, {
  origin: '*', // Mengizinkan semua origin, sesuaikan sesuai kebutuhan
});
fastify.register(import('@fastify/postgres'), {
  connectionString: `postgres://${DB_USER}:${DB_PASSWORD}@${DB_HOST}/${DB_NAME}`,
})
// Daftarkan plugin sales
fastify.register(salesPlugin);

async function startServer() {
  try {
    await fastify.listen({ port: 3000 });
    fastify.log.info(`Server listening at http://localhost:3000`);
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
}

startServer();
