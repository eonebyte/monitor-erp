import casPlugin from "./cas.mjs"
import loginPlugin from "./login.mjs"
import logoutPlugin from "./logout.mjs"

export default async function authPlugin(app, opts) {
    app.register(loginPlugin)  
    app.register(casPlugin)                
    app.register(logoutPlugin)
}