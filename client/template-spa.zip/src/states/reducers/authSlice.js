import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import CryptoJS from 'crypto-js';

const API_BASE_URL = 'http://localhost:3080/api';
const ENCRYPTION_KEY = 'apic1k4r4ng';

const encryptData = (data) => {
  return CryptoJS.AES.encrypt(JSON.stringify(data), ENCRYPTION_KEY).toString();
};

const decryptData = (data) => {
  const bytes = CryptoJS.AES.decrypt(data, ENCRYPTION_KEY);
  return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
};
// checkAuthStatus
export const cAS = createAsyncThunk('auth/cAS', async () => {
  const response = await axios.get(`${API_BASE_URL}/cAS`, { withCredentials: true });
  return response.data;
});


export const login = createAsyncThunk(
  'auth/login',
  async ({ username, password }, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/login`, { username, password }, { withCredentials: true });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const logout = createAsyncThunk('auth/logout', async () => {
  const response = await axios.get(`${API_BASE_URL}/logout`, { withCredentials: true });
  return response.data;

});

const getInitialLoggedInState = () => {
  const savedState = localStorage.getItem('uWCSA');
  if (savedState === null || savedState === undefined) {
    return false;
  }
  try {
    const decryptedState = decryptData(savedState);
    return JSON.parse(decryptedState);
  } catch (error) {
    return false;
  }
};
const getInitialUsername = () => {
  const savedUser = localStorage.getItem('pU');
  if (savedUser === null || savedUser === undefined || savedUser === '') {
    return '';
  }
  try {
    const decryptedUser = decryptData(savedUser);
    return JSON.parse(decryptedUser);
  } catch (error) {
    return '';
  }
};
const getInitialUserRole = () => {
  const savedUserRole = localStorage.getItem('uR');
  if (savedUserRole === null || savedUserRole === undefined || savedUserRole === '') {
    return '';
  }
  try {
    const decryptedUserRole = decryptData(savedUserRole);
    return JSON.parse(decryptedUserRole);
  } catch (error) {
    return '';
  }
};
// uWCSA = user Web Client Session Active
// pU = profileUser
// uR = userRole
const authSlice = createSlice({
  name: 'auth',
  initialState: {
    uWCSA: getInitialLoggedInState(),
    profilUser: getInitialUsername(),
    userRole: getInitialUserRole(),
    isLoading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(login.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(cAS.fulfilled, (state, action) => {
        state.uWCSA = action.payload.auth;
        state.profilUser = action.payload.username;
        state.userRole = action.payload.role;
        const encryptedState = encryptData(JSON.stringify(action.payload.auth));
        const encryptedProfilUser = encryptData(JSON.stringify(action.payload.username));
        const encryptedProfilUserRole = encryptData(JSON.stringify(action.payload.role));
        localStorage.setItem('uWCSA', encryptedState);
        localStorage.setItem('pU', encryptedProfilUser);
        localStorage.setItem('uR', encryptedProfilUserRole);
        state.isLoading = false;
      })
      .addCase(login.fulfilled, (state, action) => {
        state.uWCSA = action.payload.auth;
        state.profilUser = action.payload.username;
        state.userRole = action.payload.role;
        const encryptedState = encryptData(JSON.stringify(action.payload.auth));
        const encryptedProfilUser = encryptData(JSON.stringify(action.payload.username));
        const encryptedProfilUserRole = encryptData(JSON.stringify(action.payload.role));
        localStorage.setItem('uWCSA', encryptedState);
        localStorage.setItem('pU', encryptedProfilUser);
        localStorage.setItem('uR', encryptedProfilUserRole);
        state.isLoading = false;
      })
      .addCase(logout.fulfilled, (state, action) => {
        state.uWCSA = action.payload.auth;
        const encryptedState = encryptData(JSON.stringify(action.payload.auth));
        localStorage.setItem('uWCSA', encryptedState);
      })
      .addCase(login.rejected, (state, action) => {
        state.error = action.payload.error;
        state.isLoading = false;
      })
  },
});

export default authSlice.reducer;
