export function Contact() {
    return <div>Get in touch on the Contact Page!</div>;
  }