// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
// App.js
import { TabMenu } from './components/TabMenu';
function App() {
  return (
    <TabMenu />
  );
}

export default App;

